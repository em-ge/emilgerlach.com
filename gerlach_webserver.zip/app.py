# http://94.130.107.104:11000/


from flask import Flask, render_template, request
from datetime import datetime

# from flask_debugtoolbar import DebugToolbarExtension


app = Flask(__name__)


@app.route("/")
def main():
    return render_template("index.html")


@app.route("/blog")
def blog():
    return render_template("index_blog.html")


@app.route("/blog/strudel")
def article_strudel():
    return render_template("index_strudel.html")


@app.route("/playground")
def playground():
    return render_template(
        "index_playground.html",
    )


@app.route("/dev")
def dev():
    return render_template(
        "index_dev.html",
    )


@app.route("/dev/learningpython")
def learningpython():
    return render_template(
        "index_learningpython.html",
    )


@app.route("/dev/probability-calculator", methods=["GET", "POST"])
def probabilitycalc():
    i = 1
    numbers = {}
    results = ""
    check = False

    if request.method == "POST":
        while True:
            try:
                number = int(request.form[f"number{i}"])

                key = f"number{i}"

                numbers[key] = number

                i += 1

            except KeyError:
                check = True

            if check == True:
                break

        results = sum(numbers.values())

    return render_template("index_probabilitycalc.html", results=results)


@app.route("/dev/mini-ai", methods=["GET", "POST"])
def miniai():
    user_input = None

    ai_knowledge = "guitar"

    answer = "-"

    if request.method == "POST":

        user_input = request.form.get("user_input")

        str(user_input)

        if user_input.lower() in ai_knowledge:

            answer = "The guitar is the greatest instrument that ever existed"

        else:
            answer = "This mini ai has no answer to this question"

    return render_template("index_miniai.html", answer=answer)


@app.route("/family")
def family():
    start_date = datetime(2024, 1, 1)

    current_date = datetime.now()

    days_passed_calc = current_date - start_date

    days_passed = days_passed_calc.days

    end_calc = days_passed % 3

    if end_calc == 0:
        message_emil = "Emil muss Tisch decken!"
        message_lina = "Lina muss Spülmaschine ausräumen!"
        message_noah = "Noah muss Spülmaschine einräumen!"
    elif end_calc == 1:
        message_emil = "Emil muss Spülmaschine einräumen!"
        message_lina = "Lina muss Tisch decken!"
        message_noah = "Noah muss die Spülmaschine ausräumen!"
    elif end_calc == 2:
        message_emil = "Emil muss Spülmaschine ausräumen!"
        message_lina = "Lina muss Spülmaschine einräumen!"
        message_noah = "Noah muss Tisch decken!"
    else:
        message_emil = "Error, please contact emil.j.gerlach@gmail.com"

    return render_template(
        "index_family.html",
        message_emil=message_emil,
        message_noah=message_noah,
        message_lina=message_lina,
    )


@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404


# security


# Virtual device 'sata0:1' will start disconnected.


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=11000)
