# emilgerlach.com

<!--##about-->

[my website](https://emilgerlach.com), where I share my projects, articles and blog posts about tech, development, IT, science, <!--history,--> and a variety of other topics.

This website first went online in April 2024 and was my first big project.
The prototype of this website was built using a Flask web server. The site still runs on Flask. I am still working on this website and try to improve it, so please forgive any errors or issues you may encounter.

<!--##future ideas-->
<!--## License-->
<!--##Roadmap
If you have ideas for releases in the future, it is a good idea to list them in the README. or contact me-->
